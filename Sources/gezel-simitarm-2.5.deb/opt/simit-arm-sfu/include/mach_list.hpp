_MACH_DEF(1, fetch_normal)
#undef _MACH_DEF
#define _MAX_MACH_ID 1
