/*************************************************************************
    Copyright (C) 2002,2003,2004,2005 Wei Qin
    See file COPYING for more information.

    This program is free software; you can redistribute it and/or modify    
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*************************************************************************/

#ifndef __CACHE_H__
#define __CACHE_H__

#include <string>
#include "BIU.h"

namespace simulator {

struct cache_block {
	uint32_t tag;
	bool valid;
	bool dirty[2];
};

template <uint32_t n_block, uint32_t n_assoc, uint32_t bsize>
class cache {

	protected:

		uint32_t cache_index(uint32_t addr) {
			return (addr/bsize)%(n_block/n_assoc);
		}

		uint32_t cache_tag(uint32_t addr) {
			return (addr/(bsize*n_block/n_assoc));
		}

		/* ARM uses the round robin policy */
		uint32_t choose_round_robin(uint32_t index) {
			return round_robin_index[index];
		}

		void update_round_robin(uint32_t index) {
			round_robin_index[index] = (round_robin_index[index]+1)%n_assoc;
		}

		/* check if the address is in cache */
		struct cache_block *lookup(uint32_t addr) {
			uint32_t ind = cache_index(addr), tag = cache_tag(addr);
			for (uint32_t i=0; i<n_assoc; i++)
				if (data[ind][i].tag == tag && data[ind][i].valid) 
					return &data[ind][i];
			return NULL;
		}

		/* allocate a cache block, return true if eviction happened */
		struct cache_block *allocateBlock(uint32_t addr, uint32_t size) {

			uint32_t ind = cache_index(addr), tag = cache_tag(addr);
			cache_block *theblock = &data[ind][choose_round_robin(ind)];

			theblock->tag = tag;
			theblock->valid = true;
			update_round_robin(ind);
			return theblock;
		}

	public:
		cache(const std::string& name) : name(name) {
			memset(data, 0, sizeof(data));
			memset(round_robin_index, 0, sizeof(round_robin_index));
		}
		~cache() {}

	protected:
		const std::string name;

		struct cache_block data[n_block/n_assoc][n_assoc];
		uint16_t round_robin_index[n_block/n_assoc];

};

template <uint32_t n_block, uint32_t n_assoc,
	uint32_t bsize, uint32_t r_latency>
class rcache : public cache<n_block, n_assoc, bsize> {

	typedef cache<n_block, n_assoc, bsize> base_t;
	using base_t::name;
	using base_t::data;
	using base_t::round_robin_index;
	using base_t::lookup;
	using base_t::allocateBlock;

	public:

		/*constructor: set the name */
		rcache(const std::string& name, BIU& biu) :
			cache<n_block,n_assoc,bsize>(name), biu(biu),
	   		read_busy(false), latency(0), lastAddr(0),
		   	nReads(0), nReadMisses(0) {}

		~rcache() {}

		void reset() {
			memset(base_t::data, 0, sizeof(base_t::data));
			memset(base_t::round_robin_index, 0,
					sizeof(base_t::round_robin_index));
			read_busy = false;
			latency = 0;
			lastAddr = 0;
			nReads = 0;
			nReadMisses = 0;
		}

		bool read(uint32_t addr, uint32_t size) {

			if (read_busy) return false;

			/* if the still in the same block, must hit */
			if (addr/bsize == lastAddr) {
				nReads++;
				return true;
			}

			struct cache_block *block = lookup(addr);
			if (!block) {
				nReadMisses++;
				read_busy = true;

				/* read the block in */
				latency = biu.access(r_latency);
				block = allocateBlock(addr, size);

				return false;
			}

			lastAddr = addr/bsize;
			nReads++;
			return true;
		}

		void updateOnClockTick() {
			if (read_busy) {
				if (latency==0) 
					read_busy = false;
				if (latency) latency--;
			}
		}

		void PrintStats(FILE *fp) {

			fprintf(fp, "Total %s reads:       ", name.c_str());
			dump_int64(nReads, fp);
			fprintf(fp, "\nTotal %s read misses: ", name.c_str());
			dump_int64(nReadMisses, fp);
			fprintf(fp, "\n%s hit ratio:         %.3f%%\n", name.c_str(),
				100.0*(nReads-nReadMisses)/(nReads));
		}

	protected:
		BIU& biu;
		bool read_busy;
		uint32_t latency;
		uint32_t lastAddr;
		uint64_t nReads, nReadMisses;
};

template <uint32_t n_block, uint32_t n_assoc,
	uint32_t bsize, uint32_t r_latency, uint32_t w_latency>
class rwcache : public cache<n_block, n_assoc, bsize> {

	typedef cache<n_block, n_assoc, bsize> base_t;
	using base_t::name;
	using base_t::data;
	using base_t::round_robin_index;
	using base_t::lookup;
	using base_t::allocateBlock;

	private:
		/* ARM has the write buffer */
		int nFreeWBuffer;
		bool allocateWBuffer() {
			if (nFreeWBuffer<nWriteBufferEntries) {
				nFreeWBuffer++;
				return true;
			}
			return false;
		}

		bool releaseWBuffer() {
			if (nFreeWBuffer) {
				nFreeWBuffer--;
				return true;
			}
			return false;
		}


	public:

		/*constructor: set the name */
		rwcache(const std::string& name, BIU& biu) :
			cache<n_block,n_assoc,bsize>(name), 
			nFreeWBuffer(0), biu(biu),
	   		read_busy(false), write_busy(false), lastMergeable(false),
			lastWriteIndex(0), latency(0), nReads(0), nReadMisses(0),
			nWrites(0), nWriteMisses(0)	{}

		~rwcache() {}

		void reset() {
			memset(data, 0, sizeof(data));
			memset(round_robin_index, 0, sizeof(round_robin_index));
			nFreeWBuffer = 0;
			read_busy = false;
			write_busy = false;
			lastMergeable = false;
			lastWriteIndex = 0;
			latency = 0;
			nReads = 0;
			nReadMisses = 0;
			nWrites = 0;
			nWriteMisses = 0;
		}

		bool read(uint32_t addr, uint32_t size) {
#ifdef DEBUG
	fprintf(stderr, "%s read: read_busy=%d write_busy=%d latency=%d\n",
		name.c_str(), read_busy, write_busy, latency); 
#endif
			if (read_busy) return false;

			struct cache_block *block = lookup(addr);
			if (!block) {
				nReadMisses++;
				read_busy = true;

				/* read the block in */
				latency = biu.access(r_latency);
				block = allocateBlock(addr, size);

				/* add eviction cost if dirty*/
				if (block->dirty[0]) {
					block->dirty[0] = false;
					bool nWB = allocateWBuffer();
					if (!nWB) latency += biu.access(w_latency);
				}
				if (block->dirty[1]) {
					block->dirty[1] = false;
					bool nWB = allocateWBuffer();
					if (!nWB) latency += biu.access(w_latency);
				}

				return false;
			}

			nReads++;
			return true;
		}

		bool write(uint32_t addr, uint32_t size, bool mergeable) {

			/* if cache busy, cannot do anything */
			//if (write_busy) return false;

			struct cache_block *block = lookup(addr);
			/* cache hit, good */
			if (block) {
				nWrites++;
				block->dirty[(addr/(bsize/2))&1] = true;
				return true;
			}

			/* cache miss, check if mergeable */
			if (mergeable && lastMergeable) {
				if (addr/writeBufferEntrySize==lastWriteIndex) {
					nWrites++;
					nWriteMisses++;
					return true;
				}
			}

			/* not mergerable, get a new buffer */
			bool nWB = allocateWBuffer();
			if (nWB) {

				lastMergeable = mergeable;
				lastWriteIndex = addr/writeBufferEntrySize;
				nWrites++;
				nWriteMisses++;
				return true;
			}
			else {	/*wait for the buffer to be flushed */
			//	releaseWBuffer();
				return false;
			}
		}

		void updateOnClockTick() {
			if (read_busy | write_busy) {
				if (latency==0) 
					read_busy = write_busy = false;
				if (latency) latency--;
			}
			else {
				if (releaseWBuffer()) {
					write_busy = true;
					latency = biu.access(w_latency);
				}
			}
		}

		void PrintStats(FILE *fp) {

			fprintf(fp, "Total %s writes:       ", name.c_str());
			dump_int64(nWrites, fp);
			fprintf(fp, "\nTotal %s write misses: ", name.c_str());
			dump_int64(nWriteMisses, fp);
			fprintf(fp, "\nTotal %s reads:        ", name.c_str());
			dump_int64(nReads, fp);
			fprintf(fp, "\nTotal %s read misses:  ", name.c_str());
			dump_int64(nReadMisses, fp);
			fprintf(fp, "\n%s hit ratio:         %.3f%%\n", name.c_str(),
				100.0*(nReads+nWrites-nReadMisses-nWriteMisses)/
				(nReads+nWrites));
		}

	protected:
		BIU& biu;

		bool read_busy, write_busy;
		bool lastMergeable;
		uint32_t lastWriteIndex;
		uint32_t latency;
		uint64_t nReads, nReadMisses;
		uint64_t nWrites, nWriteMisses;
};

}

#endif
