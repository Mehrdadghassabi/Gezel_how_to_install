/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     POSINT = 258,
     ID = 259,
     ERRTOK = 260,
     QSTRING = 261,
     BRACE_OPEN = 262,
     BRACE_CLOSE = 263,
     COMMA = 264,
     RBRACKET_OPEN = 265,
     RBRACKET_CLOSE = 266,
     BRACKET_OPEN = 267,
     BRACKET_CLOSE = 268,
     SEMICOLON = 269,
     COLON = 270,
     DP = 271,
     TC = 272,
     NS = 273,
     IN = 274,
     OUT = 275,
     SIG = 276,
     REG = 277,
     SFG = 278,
     ALWAYS = 279,
     ASSIGN = 280,
     QMARK = 281,
     AT = 282,
     IOR = 283,
     XOR = 284,
     AND = 285,
     SHL = 286,
     SHR = 287,
     ADD = 288,
     HASH = 289,
     SUB = 290,
     MUL = 291,
     MOD = 292,
     NOT = 293,
     HARDWIRED = 294,
     SEQUENCER = 295,
     DOT = 296,
     SYSTEM = 297,
     STIMULUS = 298,
     DISPLAY = 299,
     FINISH = 300,
     HEXDISPLAY = 301,
     DECDISPLAY = 302,
     BINDISPLAY = 303,
     EQ = 304,
     NE = 305,
     GRT = 306,
     GRTEQ = 307,
     SMT = 308,
     SMTEQ = 309,
     SFGNAME = 310,
     CYCLENUM = 311,
     TOGGLENUM = 312,
     ONESNUM = 313,
     ZEROESNUM = 314,
     TRACE = 315,
     OPTION = 316,
     DPNAME = 317,
     TARGET = 318,
     STATE = 319,
     INITIALSTATE = 320,
     IF = 321,
     THEN = 322,
     ELSE = 323,
     FSM = 324,
     LOOKUP = 325,
     IPBLOCK = 326,
     IPTYPE = 327,
     IPPARM = 328,
     USE = 329
   };
#endif
/* Tokens.  */
#define POSINT 258
#define ID 259
#define ERRTOK 260
#define QSTRING 261
#define BRACE_OPEN 262
#define BRACE_CLOSE 263
#define COMMA 264
#define RBRACKET_OPEN 265
#define RBRACKET_CLOSE 266
#define BRACKET_OPEN 267
#define BRACKET_CLOSE 268
#define SEMICOLON 269
#define COLON 270
#define DP 271
#define TC 272
#define NS 273
#define IN 274
#define OUT 275
#define SIG 276
#define REG 277
#define SFG 278
#define ALWAYS 279
#define ASSIGN 280
#define QMARK 281
#define AT 282
#define IOR 283
#define XOR 284
#define AND 285
#define SHL 286
#define SHR 287
#define ADD 288
#define HASH 289
#define SUB 290
#define MUL 291
#define MOD 292
#define NOT 293
#define HARDWIRED 294
#define SEQUENCER 295
#define DOT 296
#define SYSTEM 297
#define STIMULUS 298
#define DISPLAY 299
#define FINISH 300
#define HEXDISPLAY 301
#define DECDISPLAY 302
#define BINDISPLAY 303
#define EQ 304
#define NE 305
#define GRT 306
#define GRTEQ 307
#define SMT 308
#define SMTEQ 309
#define SFGNAME 310
#define CYCLENUM 311
#define TOGGLENUM 312
#define ONESNUM 313
#define ZEROESNUM 314
#define TRACE 315
#define OPTION 316
#define DPNAME 317
#define TARGET 318
#define STATE 319
#define INITIALSTATE 320
#define IF 321
#define THEN 322
#define ELSE 323
#define FSM 324
#define LOOKUP 325
#define IPBLOCK 326
#define IPTYPE 327
#define IPPARM 328
#define USE 329




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 391 "fdl.y"
{
  char *   posint;       /* unsigned integer, hex or decimal */
  int      cmd;          /* command value */
  char *   str;          /* string buf */
  long     shash;        /* symbol hash value - parser internal */
  long     cttree;       /* compile-time expression eval stack index */
}
/* Line 1489 of yacc.c.  */
#line 205 "fdlyacc.hh"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE fdllval;

