/*************************************************************************
    Copyright (C) 2002,2003,2004,2005 Wei Qin
    See file COPYING for more information.

    This program is free software; you can redistribute it and/or modify    
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*************************************************************************/

#ifndef __MISC_H__
#define __MISC_H__

#include <config.h>
#include "bittypes.h"
#include <cstdio>

typedef uint64_t UInt64;
typedef int64_t  SInt64;
typedef uint32_t UInt32;
typedef int32_t  SInt32;
typedef uint16_t UInt16;
typedef int16_t  SInt16;
typedef uint8_t  UInt8;
typedef int8_t   SInt8;

typedef UInt64 dword_t;
typedef SInt64 sdword_t;
typedef UInt32 word_t;
typedef SInt32 sword_t;
typedef UInt16 halfword_t;
typedef SInt16 shalfword_t;
typedef UInt8 byte_t;
typedef SInt8 sbyte_t;
typedef UInt32 arm_inst_t;
typedef UInt32 arm_addr_t;
typedef UInt32 BOOL;

typedef arm_addr_t target_addr_t;

#define TRUE 1
#define FALSE 0

#define COND (inst>>28)
#define OPCD ((inst>>20)&255)
#define DOPC ((inst>>21)&15)	/*DPI's opcode*/

#define RDFLD ((inst>>12)&15)
#define RNFLD ((inst>>16)&15)
#define RMFLD (inst&15)
#define RSFLD ((inst>>8)&15)

#define WRITE_REG(ind, val) (write_gpr(ind,val))
#define READ_REG(ind) (read_gpr(ind))

#define WRITE_REG2(ind, val) (write_gpr2(ind,val))

#define READ_CPSR (read_cpsr())
#define READ_SPSR (read_spsr())
#define READ_CC (read_cc())

#define WRITE_CPSR(val) (write_cpsr(val))
#define WRITE_SPSR(val) (write_spsr(val))
#define WRITE_CC(val) (write_cc(val))

#define CPSR READ_CPSR
#define SPSR READ_SPSR
#define CC READ_CC

#define FPIND 11
#define IPIND 12
#define SPIND 13
#define LRIND 14
#define PC_AHEAD_IND 15
#define PC_REAL_IND 16
#define NUM_GPR 17

#define RD READ_REG(RDFLD)
#define RN READ_REG(RNFLD)
#define RM READ_REG(RMFLD)
#define RS READ_REG(RSFLD)
#define FP READ_REG(FPIND)
#define IP READ_REG(IPIND)
#define SP READ_REG(SPIND)
#define LR READ_REG(LRIND)
#define PC READ_REG(PC_AHEAD_IND)

#define N_FLAG ((CC>>3)&1)
#define Z_FLAG ((CC>>2)&1)
#define C_FLAG ((CC>>1)&1)
#define V_FLAG ((CC>>0)&1)

#define SET_N WRITE_CC(CC|(1<<3))
#define SET_Z WRITE_CC(CC|(1<<2))
#define SET_C WRITE_CC(CC|(1<<1))
#define SET_V WRITE_CC(CC|(1<<0))

#define CLEAR_N WRITE_CC(CC&(~(1<<3)))
#define CLEAR_Z WRITE_CC(CC&(~(1<<2)))
#define CLEAR_C WRITE_CC(CC&(~(1<<1)))
#define CLEAR_V WRITE_CC(CC&(~(1<<0)))

#define ASGN_N(n) {if (n) SET_N; else CLEAR_N;}
#define ASGN_Z(n) {if (n) SET_Z; else CLEAR_Z;}
#define ASGN_C(n) {if (n) SET_C; else CLEAR_C;}
#define ASGN_V(n) {if (n) SET_V; else CLEAR_V;}

#define ASM_CONDS(n,z,c,v) (((n)<<3)|((z)<<2)|((c)<<1)|(v))
#define ASGN_CONDS(cond) WRITE_CC(cond)

#define SFLD ((inst>>20)&1)

#define MEM_SET(addr, val, size) (mem.set_block(addr, val, size))
#define MEM_READ(buf, addr, size) (mem.read_block(buf, addr, size))
#define MEM_WRITE(addr, buf, size) (mem.write_block(addr, buf, size))

#define MEM_READ_DWORD(addr) (mem.read_dword(addr))
#define MEM_WRITE_DWORD(addr,val) (mem.write_dword(addr,val))

#define MEM_READ_WORD(addr) (mem.read_word(addr))
#define MEM_WRITE_WORD(addr,val) (mem.write_word(addr,val))

#define MEM_READ_HALF_WORD(addr) (mem.read_half_word(addr))
#define MEM_WRITE_HALF_WORD(addr,val) (mem.write_half_word(addr,val))

#define MEM_READ_BYTE(addr) (mem.read_byte(addr))
#define MEM_WRITE_BYTE(addr,val) (mem.write_byte(addr,val))


/* stack grows to smaller address, mmap area grows toward bigger address */
/* 0xd0000000 to MMAP_BASE is used by floating point emulation, see nwfpe.h */
#define STACK_BASE 0xc0000000
#define MMAP_BASE  0xd4000000
#define MAX_ENVIRON (16 * 1024)
#define STACK_SIZE (1024 * 1024)

#define BIT31(a) ((UInt32)(a)>>31)
#define BIT0(a)  ((a)&1)
#define BITn(a,b) (((UInt32)(a)>>(b))&1)

#define IN_PRVLG (((CPSR)&0x1F)!=0x10)
#define HAS_SPSR ((((CPSR)&0x1F)!=0x10) && (((CPSR)&0x1F)!=0x1F))

#ifdef COUNT_INST
#define EMULATOR_STUB(a,b) increment_counter(incr_ ## a);
#else
#define EMULATOR_STUB(a,b)
#endif

extern const char *arm_conditional[];
extern const char *arm_regnames[];
extern const char *arm_shift[];

uint64_t ato_uint64(char *input);

void dump_int64(uint64_t, FILE *);
void dump_int64_smart(uint64_t, FILE *);

/*target endianness*/
#define TARGET_LITTLE_ENDIAN 1

/*host endianness*/
#ifndef WORDS_BIGENDIAN
#define WORDS_BIGENDIAN 0
#endif

#undef _MODULARIZE_

#define IMPL_FORMALS arm_inst_t inst
#define IMPL_ARGS    inst


#endif
