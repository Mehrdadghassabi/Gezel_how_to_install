/*************************************************************************
    Copyright (C) 2002,2003,2004,2005 Wei Qin
    See file COPYING for more information.

    This program is free software; you can redistribute it and/or modify    
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*************************************************************************/

#ifndef __ARMEMUL_H__
#define __ARMEMUL_H__

#include <cstdio>
#include <misc.h>
#include "emumem.h"

#define DEF_CLASS(a,b) a,
typedef enum {
#include "inst_class.h"
} inst_class;


extern void initialize(bool, bool);

namespace emulator {
class device_master;
}

/* number of instructions */
extern UInt64 icount;

/* number of nullified instructions */
extern UInt64 ncount;
		
/* number of executed instructions in each class */
extern UInt64 counters[INST_TOTAL];

extern bool running;
extern bool debuging;

/* registers */
struct regs_t {
	word_t gpr[NUM_GPR];
	word_t cpsr;
	word_t spsr;
	word_t cc;
};

extern struct regs_t my_regs;

/* memory */
extern emulator::memory mem;

extern bool verbose;
extern bool emulate_syscall;
extern target_addr_t brk_point;
extern target_addr_t mmap_brk_point;

/* emulating fpe */
extern bool in_fpe;

/* dpi carries */
extern word_t shifter_carry;
extern word_t alu_carry;

extern emulator::device_master *dev_master;


/* run the program */
extern UInt64 run_count(UInt64 count);

/* stop running */
extern void stop();

/* is running? */
extern bool is_running();

/* set running */
extern void set_running();

/* execute one instruction */
extern void execute(arm_inst_t inst, word_t addr);

/* debug an application */
extern void debug();

/* stop running */
extern void stop_debug();

/* is debuging */
extern bool is_debugging();

/* stats output */
extern void dump_instruction_counters(FILE *);

/* stats initialization */
extern void reset_instruction_counters();

/* increment counter */
static inline void increment_counter(inst_class c) {counters[c]++;}

static inline word_t get_pc() {return my_regs.gpr[PC_REAL_IND];}

static inline word_t read_gpr(int index) {return my_regs.gpr[index];}

static inline void write_gpr(int index, word_t val) {
	my_regs.gpr[index==15?PC_REAL_IND:index] = val;
}

static inline void write_gpr2(int index, word_t val) {
	my_regs.gpr[index] = val;
}

static inline word_t read_cpsr() {
	return my_regs.cpsr&0xfffffff | (my_regs.cc&0xf)<<28;
}

static inline word_t read_spsr() {return my_regs.spsr;}

static inline word_t read_cc() {return my_regs.cc;}

static inline void write_cpsr(word_t val) {
	my_regs.cpsr=val;
	my_regs.cc=(val>>28)&0xf;
}

static inline void write_spsr(word_t val) {my_regs.spsr=val;}
static inline void write_cc(word_t val) {my_regs.cc=val;}

/* fetch an instruction */
static inline word_t fetch_inst(arm_addr_t addr) {
	return mem.read_word_fast(addr);
}

/* set brk point for syscall emulation */
extern void set_brk(arm_addr_t addr);
extern void set_mmap_brk(arm_addr_t addr);

extern void load_program(const char *, int argc, char *argv[], char *env[]);
extern void load_fpe(const char *);

/* counters */
static inline UInt64 get_icount() {return icount;}
static inline UInt64 get_ncount() {return ncount;}

/* reset */
extern void reset();

/* initialize registers */
extern void init_registers();

/* debug routines */
extern void debug_trace(int count);
extern void debug_go_to(arm_addr_t addr);
extern void debug_dump_registers(FILE *stream);
extern void debug_disasm(FILE *stream, arm_addr_t addr);
extern void debug_dump(FILE *stream, arm_addr_t addr);


#endif
