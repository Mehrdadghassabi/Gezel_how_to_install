/*************************************************************************
    Copyright (C) 2002,2003,2004,2005 Wei Qin
    See file COPYING for more information.

    This program is free software; you can redistribute it and/or modify    
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*************************************************************************/

DEF_CLASS(INST_MOV, "mov    ")
DEF_CLASS(INST_MVN, "mvn    ")
DEF_CLASS(INST_ADD, "add    ")
DEF_CLASS(INST_ADC, "adc    ")
DEF_CLASS(INST_SUB, "sub    ")
DEF_CLASS(INST_SBC, "sbc    ")
DEF_CLASS(INST_RSB, "rsb    ")
DEF_CLASS(INST_RSC, "rsc    ")
DEF_CLASS(INST_AND, "and    ")
DEF_CLASS(INST_EOR, "eor    ")
DEF_CLASS(INST_ORR, "orr    ")
DEF_CLASS(INST_BIC, "bic    ")
DEF_CLASS(INST_CMP, "cmp    ")
DEF_CLASS(INST_CMN, "cmn    ")
DEF_CLASS(INST_TST, "tst    ")
DEF_CLASS(INST_TEQ, "teq    ")
DEF_CLASS(INST_MLA, "mla    ")
DEF_CLASS(INST_MUL, "mul    ")
DEF_CLASS(INST_SMLAL, "smlal  ")
DEF_CLASS(INST_SMULL, "smull  ")
DEF_CLASS(INST_UMLAL, "umlal  ")
DEF_CLASS(INST_UMULL, "umull  ")
DEF_CLASS(INST_LDR_IMM, "ldr_imm")
DEF_CLASS(INST_LDR_REG, "ldr_reg")
DEF_CLASS(INST_STR_IMM, "str_imm")
DEF_CLASS(INST_STR_REG, "str_reg")
DEF_CLASS(INST_LDM, "ldm    ")
DEF_CLASS(INST_STM, "stm    ")
DEF_CLASS(INST_SWAP, "swap   ")
DEF_CLASS(INST_SYSCALL, "syscall")
DEF_CLASS(INST_BR, "br     ")
DEF_CLASS(INST_BL, "bl     ")
DEF_CLASS(INST_MSR, "msr    ")
DEF_CLASS(INST_MRS, "mrs    ")
DEF_CLASS(INST_FPE, "fpe    ")
DEF_CLASS(INST_CPLD, "cpld   ")
DEF_CLASS(INST_CPST, "cpst   ")
DEF_CLASS(INST_UNKNOWN, "unknown")
DEF_CLASS(INST_TOTAL, NULL)

#undef DEF_CLASS
