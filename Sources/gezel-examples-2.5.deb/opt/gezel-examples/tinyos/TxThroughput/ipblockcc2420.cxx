#include "ipblockcc2420.h"

extern "C" aipblock *create_ipblockcc2420(char *instname) {
  return new ipblockcc2420(instname);
}

ipblockcc2420::ipblockcc2420(char *name) : aipblock(name) { 
}

void ipblockcc2420::setparm(char *name) {
  cerr << "ipblockcc2420: Parameter " << name << " not understood\n";
}

void ipblockcc2420::run() {
  ioval[0]->assignulong(0);
  ioval[1]->assignulong(0);
  ioval[2]->assignulong((glbRTCycle / 500000) % 2);
  //  if (glbRTCycle < 500000) 
  //    ioval[2]->assignulong(0);
  //  else
  //    ioval[2]->assignulong(1);
  ioval[3]->assignulong(0);
  ioval[7]->assignulong(0);
}

//ipblock m_cc2420(out fifo, fifop, cca, sfd : ns(1);
//            in  ss, sck, mosi : ns(1);
//            out miso : ns(1)) {
//  iptype "ipblockcc2420";
//}

bool ipblockcc2420::checkterminal(int n, char *tname, aipblock::iodir d) {
  switch (n) {
  case 0:
    return (isoutput(d) && isname(tname, "fifo"));
    break;
  case 1:
    return (isoutput(d) && isname(tname, "fifop"));
    break;
  case 2:
    return (isoutput(d) && isname(tname, "cca"));
    break;
  case 3:
    return (isoutput(d) && isname(tname, "sfd"));
    break;
  case 4:
    return (isinput(d) && isname(tname, "ss"));
    break;
  case 5:
    return (isinput(d) && isname(tname, "sck"));
    break;
  case 6:
    return (isinput(d) && isname(tname, "mosi"));
    break;
  case 7:
    return (isoutput(d) && isname(tname, "miso"));
    break;
  }
  return false;
}

bool ipblockcc2420::needsWakeupTest() {
  if (glbRTCycle == 500000)
    return true;
  return false;
}

bool ipblockcc2420::cannotSleepTest() {
  return false;
}
