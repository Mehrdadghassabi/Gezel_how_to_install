
#ifndef _SFU_H_
#define _SFU_H_

#include "bittypes.h"

namespace simulator {

// This file defines combinational SystemC modules for
// as special function units of the ARM processor.


  class sfu2x2_1 {
  public:
    sfu2x2_1() {}

    // modify update() to implement desired function
    void update();

  };

  class sfu2x2_2 {
  public:
    sfu2x2_2() {}

    // modify update() to implement desired function
    void update();

  };

  class sfu3x1_1 {
  public:
    sfu3x1_1() {}

    // modify update() to implement desired function
    void update();

  };

  class sfu3x1_2 {
  public:
    sfu3x1_2() {}

    // modify update() to implement desired function
    void update();

  };

  class sfu2x1_1 {
  public:
    sfu2x1_1() {}

    // modify update() to implement desired function
    void update();

  };

  class sfu2x1_2 {
  public:
    sfu2x1_2() {}

    // modify update() to implement desired function
    void update();

  };

}

#endif
