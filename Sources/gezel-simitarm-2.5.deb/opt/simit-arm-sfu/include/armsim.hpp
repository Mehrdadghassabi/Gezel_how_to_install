/*************************************************************************
    Copyright (C) 2002,2003,2004,2005 Wei Qin
    See file COPYING for more information.

    This program is free software; you can redistribute it and/or modify    
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*************************************************************************/

#ifndef __ARMSIMUL_H__
#define __ARMSIMUL_H__

#include <list>


#include "parms.h"

#include "more_managers.hpp"
#include "object_pool.hpp"

#include "sfu.hpp"

extern void ext_write_sfu2x2(unsigned index);
extern void ext_write_sfu3x1(unsigned index);
extern void ext_write_sfu2x1(unsigned index);
extern void ext_show_clock();

/* forward declaration*/
namespace emulator {
	class memory;
	class device_master;
}

namespace simulator {

typedef class rcache<nICacheBlocks, nICacheAssoc,
		ICacheLineSize, memoryReadLatency> ICache; 
typedef class rwcache<nDCacheBlocks, nDCacheAssoc,
		DCacheLineSize, memoryReadLatency, memoryWriteLatency> DCache;
typedef class rcache<nITLBBlocks, nITLBAssoc, IPageSize, tlbLoadLatency> ITLB;
typedef class rcache<nDTLBBlocks, nDTLBAssoc, DPageSize, tlbLoadLatency> DTLB;

/* forward declaration */
class device_emulator;

class arm_simulator {
  // coprocessor
  
  
  // special function units
  sfu2x2_1 *sfu22_1;
  sfu2x2_2 *sfu22_2;
  sfu3x1_1 *sfu31_1;
  sfu3x1_2 *sfu31_2;
  sfu2x1_1 *sfu21_1;
  sfu2x1_2 *sfu21_2;

public:
  uint32_t sfu22_s1[2];
  uint32_t sfu22_s2[2];
  uint32_t sfu22_d1[2];
  uint32_t sfu22_d2[2];
  
  uint32_t sfu31_s1[2];
  uint32_t sfu31_s2[2];
  uint32_t sfu31_s3[2];
  uint32_t sfu31_d1[2];
  
  uint32_t sfu21_s1[2];
  uint32_t sfu21_s2[2];
  uint32_t sfu21_d1[2];

private:
  enum _machine_id {
    _mach_dummy,
#define _MACH_DEF(_a,_b) _mach_ ## _b,
#include "mach_list.hpp"
    _mach_total,
  };
  
public:
  
  /** Constructor.
   *  @param verbose Verbose mode
   */
  arm_simulator(bool verbose);
  
  /** Destructor. */
  ~arm_simulator();
  
  /** Initialize the simulation state.
   */
  void initialize();
  
  /** simulate for n cycles.
   *  @param n The maximum number of cycles to simulate (may exit).
   */
  void run(UInt64 n);
  
  /** simulate one cycle. */
  void clock_tick();
  
  /** stop running. 
   *  Called by the signal handler or syscall interpreter.
   */
  void stop() {running = false;}
  
  /** See if the simulator is running.
   */
  bool is_running() const {return running;}
  
  /** Stop debuging, useless here.
   *  Kept only to satisfy syscall.cpp.
   */
  void stop_debug() {debuging = false;}
  
  /** See if in debugging mode, useless here.
   *  Kept only to satisfy syscall.cpp.
   */
  bool is_debugging() {return debuging;}
  
  /** stats output. */
  void dump_stats(FILE *fp);
  
  /** stats resetting. */
  void reset_stats();
  
  /* set brk point for syscall interpretation. */
  void set_brk(arm_addr_t addr) {brk_point = addr;}
  void set_mmap_brk(arm_addr_t addr) {mmap_brk_point = addr;}
  
  /** load the program into memory. */
  void load_program(const char *, int argc, char *argv[], char *env[]);
  
  /** load fpe emulation library into memory. */
  void load_fpe(const char *);
  
  /** reset */
  void reset();
  
  /** Get the value of a register. For debugging use. */
  word_t read_gpr(int ind) const {
    return mRF->get_value(ind).val();
  }
  
  /** These two hooks for the syscall interpretor. */
  void write_gpr(int ind, word_t val) {
    mRF->set_value(ind, val);
  }
  
  void write_gpr2(int ind, word_t val) {
    mRF->set_value(ind, val);
  }
  
  uint64_t get_cycle_count() const {return cycle_count;}
  
  word_t read_cpsr() {return mCPSR->get_value().val();}
  void write_cpsr(word_t val) {mCPSR->set_value(val);}
  
#if 0
  word_t read_spsr() {return my_regs.spsr;}
  
  void write_spsr(word_t val) {my_regs.spsr=val;}
#endif
  
  
private:
  /* status flags */
  bool running;
  bool debuging;
  
  uint64_t cycle_count;	/* number of simulation cycles*/
  
  std::list<_opt_machine_ *> work_list;
  std::list<_opt_machine_ *>::iterator work_it, ins_it;
  
public:
  /* syscall data */
  bool verbose;
  bool emulate_syscall;
  target_addr_t brk_point;
  target_addr_t mmap_brk_point;
  
  /* emulating fpe */
  bool in_fpe;
  
public:
  
  uint64_t alloc_count;	/* number of machine allocations. */
  uint64_t retire_count;	/* number of machine retires. */
  
  /* Allocate a machine of given id type. */
  _opt_machine_ *allocate_machine(_MACH_ID_T id);
  
  /* This is the sink of OSMs. */
  void sink_machine(_opt_machine_ *mach);
  
  /* Get a new machine.
   * This is the source of OSMs.
   */
  _opt_machine_ *source_machine();
  
  /** Activate a new machine.
   *  @param id The id of the machine.
   */
  void activate_machine(_MACH_ID_T id);

private:
    
  static _opt_machine_ *mach_allocator(arm_simulator *, _MACH_ID_T id);
  
  /* storage for machine objects. */
  obj_pool<_opt_machine_, _MACH_ID_T, arm_simulator,
	   arm_simulator::mach_allocator> *machine_pool;
  
  int print_trace_flag;

  /*hardware units */
  
public:
  /* enable/disable instruction tracing */
  void enable_print_trace();
  void disable_print_trace();
  
public:
  
  /* caches, TLBs & bus interface unit, modeling timing only */
  ICache *icache;
  DCache *dcache;
  ITLB *itlb;
  DTLB *dtlb;
  BIU *biu;
  
  /* the token managers */
#define MANG_DEF(cname, iname) cname *iname;
#include "mang_list.hpp"
  
  emulator::device_master *dev_master;
  
  /* memory saving the real data value */
  emulator::memory *mem;
  
public:
  
  /* special function unit methods */
  // read back the computation result from SFU
  void sfu2x2_read(unsigned index, uint32_t &val1, uint32_t &val2) {
    assert(index<2);
    val1 = sfu22_d1[index];
    val2 = sfu22_d2[index];      
    // std::cerr << "sfu2x2_read: " << val1 << " " << val2 << "\n";
  }
  
  // write source operands to SFU
  void sfu2x2_write(unsigned index, uint32_t val1, uint32_t val2) {
    assert(index<2);
    sfu22_s1[index] = val1;
    sfu22_s2[index] = val2;      
    //    std::cerr << "sfu2x2_write: " << val1 << " " << val2 << "\n";
    ext_write_sfu2x2(index);
  }
  
  /* special function unit methods */
  // read back the computation result from SFU
  void sfu3x1_read(unsigned index, uint32_t &val) {
    assert(index<2);
    val = sfu31_d1[index];
  }
  
  // write source operands to SFU
  void sfu3x1_write(unsigned index, uint32_t val1,
		    uint32_t val2, uint32_t val3) {
    assert(index<2);
    sfu31_s1[index] = val1;
    sfu31_s2[index] = val2;
    sfu31_s3[index] = val3;
    ext_write_sfu3x1(index);
  }
  
  /* special function unit methods */
  // read back the computation result from SFU
  void sfu2x1_read(unsigned index, uint32_t &val) {
    assert(index<2);
    val = sfu21_d1[index];
  }
  
  // write source operands to SFU
  void sfu2x1_write(unsigned index, uint32_t val1, uint32_t val2) {
    assert(index<2);
    sfu21_s1[index] = val1;
    sfu21_s2[index] = val2;
    ext_write_sfu2x1(index);
  }
  
  void coproc_start(uint32_t inst) {}
  bool coproc_busy() {return false; }
  unsigned coproc_status() {return 0;}
  
private:

  /* regular update of coprocessor interface */
  void coproc_update() { }
 
};

}

#endif
