#include "ipblock.h"

#ifndef ipblockcc2420_H
#define ipblockcc2420_H

class ipblockcc2420 : public aipblock {
  vector<gval *> content;
  int wlen, alen;
  int ramset;
public:
  ipblockcc2420(char *name);
  void setparm(char *_name);
  void run();
  bool checkterminal(int n, char *tname, aipblock::iodir d);
  bool needsWakeupTest();
  bool cannotSleepTest();
  void generate_vhd_view();
};

#endif
